document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("joinBtn").addEventListener("click", function () {
        window.location.href = "courses.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("enrollbtn").addEventListener("click", function () {
        window.location.href = "courseDetail.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("material-btn").addEventListener("click", function () {
        window.location.href = "courseMaterials.html"
    });
});



document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("courses-btn").addEventListener("click", function () {
        window.location.href = "dashboardCourses.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("materials-btn").addEventListener("click", function () {
        window.location.href = "dashboardMaterials.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("quiz-btn").addEventListener("click", function () {
        window.location.href = "dashboardQuiz.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("progress-btn").addEventListener("click", function () {
        window.location.href = "dashboardProgTrack.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("schedule-btn").addEventListener("click", function () {
        window.location.href = "dashboardSchedule.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("certicate-btn").addEventListener("click", function () {
        window.location.href = "dashboardCertificate.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("info-btn").addEventListener("click", function () {
        window.location.href = "dashboardInfo.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("menu-btn").addEventListener("click", function () {
        window.location.href = "dashboardMenu.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("indivquiz-btn").addEventListener("click", function () {
        window.location.href = "dashboardIndivQuiz.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("quiz-btn2").addEventListener("click", function () {
        window.location.href = "AdminQuiz.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("materials-btn2").addEventListener("click", function () {
        window.location.href = "AdminMaterial.html"
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("courses-btn2").addEventListener("click", function () {
        window.location.href = "AdminCourses.html"
    });
});