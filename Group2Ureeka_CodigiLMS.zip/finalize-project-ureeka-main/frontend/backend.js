document.addEventListener('DOMContentLoaded', function() {
    // Get the form element
    const form = document.getElementById('basicInfoForm');
    
    // Add submit event listener
    form.addEventListener('submit', function(event) {
        // Prevent the default form submission
        event.preventDefault();
        
        // Call the function to handle form submission
        handleFormSubmit(this);
    });
});

function handleFormSubmit(form) {
    // Create a result container to display the API response
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = 'Processing...';
    resultDiv.style.display = 'block';
    
    // Convert form data to JSON
    const jsonData = convertFormToJson(form);
    
    // Log the JSON data (for debugging)
    console.log('Form data converted to JSON:', jsonData);
    
    // Call the API with the JSON data
    callRestApi(jsonData, resultDiv);
}


function convertFormToJson(form) {
    // Create an object to hold the form data
    const formData = {};
    
    // Get all form elements
    const elements = form.elements;
    
    // Process each form element
    for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        const name = element.name;
        
        // Skip elements without a name or submit buttons
        if (!name || element.type === 'submit') {
            continue;
        }
        
        // Handle different input types
        if (element.type === 'checkbox') {
            // For checkboxes, we need to collect all selected values
            if (!formData[name]) {
                formData[name] = [];
            }
            
            if (element.checked) {
                formData[name].push(element.value);
            }
        } else if (element.type === 'radio') {
            // For radio buttons, only add the selected one
            if (element.checked) {
                formData[name] = element.value;
            }
        } else if (element.type === 'number') {
            // Convert number inputs to actual numbers
            formData[name] = element.value !== '' ? Number(element.value) : null;
        } else {
            // For other input types, just get the value
            formData[name] = element.value;
        }
    }
    
    // Convert the form data object to a JSON string
    return JSON.stringify(formData);
}


function callRestApi(jsonData, resultDiv) {
    // Define the API endpoint
    const apiUrl = 'http://127.0.0.1:8000/course/create/{admin_id}'// Replace with your actual API endpoint
    
    // Create request options
    const requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: jsonData // Our JSON string
    };
    
    // Show loading indicator
    resultDiv.innerHTML = '<p>Sending data to API...</p>';
    
    // Make the fetch request
    fetch(apiUrl, requestOptions)
        .then(response => {
            // Check if the request was successful
            if (!response.ok) {
                throw new Error('Network response was not ok, status: ' + response.status);
            }
            
            // Parse the JSON response
            return response.json();
        })
        .then(data => {
            // Handle the successful response
            console.log('Success:', data);
            
            // Display the result
            resultDiv.innerHTML = `
                <h3>Registration Successful!</h3>
                <p>User ID: ${data.userId || 'N/A'}</p>
                <p>Thank you for registering, ${data.name || 'User'}!</p>
                <pre>${JSON.stringify(data, null, 2)}</pre>
            `;
        })
        .catch(error => {
            // Handle errors
            console.error('Error:', error);
            
            // Display error message
            resultDiv.innerHTML = `
                <h3>Error</h3>
                <p>There was a problem with your registration:</p>
                <p>${error.message}</p>
            `;
        });
}


// function validateForm(form) {
//     // Basic validation
//     const name = form.elements['name'].value.trim();
//     if (name === '') {
//         return { valid: false, message: 'Please enter your name.' };
//     }
    
//     const email = form.elements['email'].value.trim();
//     if (email === '' || !email.includes('@')) {
//         return { valid: false, message: 'Please enter a valid email address.' };
//     }
    
//     const age = form.elements['age'].value;
//     if (age === '' || isNaN(age) || Number(age) < 18) {
//         return { valid: false, message: 'Please enter a valid age (18 or older).' };
//     }
    
//     // If all validations pass
//     return { valid: true };
// }

// Update the handleFormSubmit function with validation
function handleFormSubmit(form) {
    // Validate the form
    // const validation = validateForm(form);
    
    // If validation fails, show error message
    // if (!validation.valid) {
    //     const resultDiv = document.getElementById('result');
    //     resultDiv.innerHTML = <p class="error">${validation.message}</p>;
    //     resultDiv.style.display = 'block';
    //     return;
    // }
    
    // Continue with form submission as before
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = 'Processing...';
    resultDiv.style.display = 'block';
    
    // Convert form data to JSON
    const jsonData = convertFormToJson(form);
    
    // Call the API with the JSON data
    callRestApi(jsonData, resultDiv);
}


function convertFormToJson(form) {
    // Create a FormData object from the form
    const formData = new FormData(form);
    
    // Create an object to hold the form data
    const formJson = {};
    
    // Process each form field
    formData.forEach((value, key) => {
        // Check if the key already exists in the object
        if (formJson[key] !== undefined) {
            // If it does, convert it to an array if it's not already
            if (!Array.isArray(formJson[key])) {
                formJson[key] = [formJson[key]];
            }
            // Add the new value to the array
            formJson[key].push(value);
        } else {
            // Otherwise, just set the value
            formJson[key] = value;
        }
    });
    
    // Special handling for checkboxes (which might be arrays)
    // if (formJson.interests && !Array.isArray(formJson.interests)) {
    //     formJson.interests = [formJson.interests];
    // }
    
    // Convert numeric fields to numbers
    // if (formJson.age) {
    //     formJson.age = Number(formJson.age);
    // }
    
    // Convert the form data object to a JSON string
    return JSON.stringify(formJson);
}

